export interface OptionType {
  key: string;
  value: string;
}
export type SelectOptionType = OptionType[]