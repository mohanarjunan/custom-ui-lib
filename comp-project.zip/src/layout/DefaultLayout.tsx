import React from "react";
import SideBar from "../components/common/SideBarComponent";
import TopBar from "../components/common/TopBarComponent";

type DefaultLayoutProps = {
  children: React.ReactNode;
};

export default function DefaultLayout({ children }: DefaultLayoutProps) {
  return (
    <>
    </>
  );
}
